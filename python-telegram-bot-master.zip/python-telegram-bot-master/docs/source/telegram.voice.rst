telegram.Voice
==============

.. autoclass:: telegram.Voice
    :members:
    :show-inheritance:
