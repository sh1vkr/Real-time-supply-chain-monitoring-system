telegram.InlineQueryResultGame
==============================

.. autoclass:: telegram.InlineQueryResultGame
    :members:
    :show-inheritance:
