telegram.ext.Handler
====================

.. autoclass:: telegram.ext.Handler
    :members:
    :undoc-members:
    :show-inheritance:
