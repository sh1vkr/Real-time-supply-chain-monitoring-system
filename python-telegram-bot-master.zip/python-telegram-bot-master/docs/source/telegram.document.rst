telegram.Document
=================

.. autoclass:: telegram.Document
    :members:
    :show-inheritance:
