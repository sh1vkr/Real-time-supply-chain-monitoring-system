telegram.Video
==============

.. autoclass:: telegram.Video
    :members:
    :show-inheritance:
