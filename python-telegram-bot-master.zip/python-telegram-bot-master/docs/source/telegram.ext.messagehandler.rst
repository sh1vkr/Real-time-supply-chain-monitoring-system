telegram.ext.MessageHandler
===========================

.. autoclass:: telegram.ext.MessageHandler
    :members:
    :show-inheritance:
