telegram.InputMediaAnimation
============================

.. autoclass:: telegram.InputMediaAnimation
    :members:
    :show-inheritance:
