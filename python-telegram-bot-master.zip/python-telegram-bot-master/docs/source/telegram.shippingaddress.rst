telegram.ShippingAddress
========================

.. autoclass:: telegram.ShippingAddress
    :members:
    :show-inheritance:
