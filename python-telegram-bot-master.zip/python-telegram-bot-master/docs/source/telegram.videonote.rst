telegram.VideoNote
==================

.. autoclass:: telegram.VideoNote
    :members:
    :show-inheritance:
