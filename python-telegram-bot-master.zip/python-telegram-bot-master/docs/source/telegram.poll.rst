telegram.Poll
=============

.. autoclass:: telegram.Poll
    :members:
    :show-inheritance:
