telegram.LoginUrl
=================

.. autoclass:: telegram.LoginUrl
    :members:
    :show-inheritance:
