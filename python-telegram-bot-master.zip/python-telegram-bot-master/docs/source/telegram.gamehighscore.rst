telegram.GameHighScore
======================

.. autoclass:: telegram.GameHighScore
    :members:
    :show-inheritance:
