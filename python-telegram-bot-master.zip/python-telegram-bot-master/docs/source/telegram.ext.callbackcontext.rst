telegram.ext.CallbackContext
============================

.. autoclass:: telegram.ext.CallbackContext
    :members:
