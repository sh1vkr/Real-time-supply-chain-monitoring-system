telegram.InlineQueryResultVideo
===============================

.. autoclass:: telegram.InlineQueryResultVideo
    :members:
    :show-inheritance:
